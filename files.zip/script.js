/* =====================================================
   AI Explorers — script.js
   Edit the DATA section below to change content.
   ===================================================== */
document.documentElement.classList.add('js');

/* ---------- DATA ---------- */

// Overview cards (icon names come from https://lucide.dev/icons)
const TOPICS = [
  { id: 'goal', icon: 'target', title: 'ما الهدف من الذكاء الاصطناعي؟', accent: '#4F46E5', bg: '#E0E7FF' },
  { id: 'role', icon: 'globe', title: 'ما دور الذكاء الاصطناعي؟', accent: '#0E7490', bg: '#CFFAFE' },
  { id: 'ethics', icon: 'scale', title: 'ما أخلاقيات استخدامه؟', accent: '#BE185D', bg: '#FCE7F3' },
  { id: 'pros-cons', icon: 'git-compare', title: 'ما إيجابياته وسلبياته؟', accent: '#B45309', bg: '#FEF3C7' }
];

// Image for the square in the "goal" section. Paste a URL or a local path like 'images/goal.jpg'.
// While empty, the robot illustration is shown.
const GOAL_IMAGE = '';

// Application cards. To use a real photo, set image: 'URL' (an <img> is layered over the gradient;
// if it fails to load it is removed and the gradient + icon remain).
const APPLICATIONS = [
  { icon: 'book-open', title: 'التعليم', c1: '#4F46E5', c2: '#38BDF8', image: '',
    short: 'يساعد كل طالب على التعلم بالسرعة التي تناسبه.',
    more: 'بعض المنصات التعليمية تلاحظ الأسئلة التي تخطئ فيها وتقترح تمارين إضافية عليها، كما تشرح الدرس بطرق مختلفة.',
    note: 'المعلّم يبقى هو من يوجّه الطلاب ويقيّم فهمهم.' },
  { icon: 'stethoscope', title: 'الطب', c1: '#0F766E', c2: '#2DD4BF', image: '',
    short: 'يساعد الأطباء في قراءة الصور الطبية واكتشاف المشكلات مبكرًا.',
    more: 'يمكن لبعض البرامج فحص صور الأشعة وتنبيه الطبيب إلى مناطق تستحق الانتباه.',
    note: 'الطبيب هو من يتخذ قرار التشخيص والعلاج.' },
  { icon: 'sprout', title: 'الزراعة', c1: '#15803D', c2: '#86EFAC', image: '',
    short: 'يساعد المزارعين على العناية بالنباتات وتوفير المياه.',
    more: 'تلتقط الطائرات المسيّرة صورًا للحقول، وتحللها البرامج لمعرفة النباتات العطشى أو المريضة.',
    note: 'خبرة المزارع تظل أساسية لفهم أرضه ومحصوله.' },
  { icon: 'car-front', title: 'المواصلات', c1: '#1D4ED8', c2: '#93C5FD', image: '',
    short: 'يساعد في اختيار أفضل الطرق وتنظيم حركة المرور.',
    more: 'تعتمد تطبيقات الخرائط على بيانات الطرق لتقترح مسارًا أسرع، وتجرب بعض المركبات ميزات القيادة المساعِدة.',
    note: 'السائق يجب أن يبقى منتبهًا ومسؤولًا.' },
  { icon: 'telescope', title: 'العلوم والأبحاث', c1: '#172554', c2: '#6366F1', image: '',
    short: 'يسرّع تحليل البيانات الضخمة التي يجمعها العلماء.',
    more: 'يساعد في فرز صور الفضاء، ودراسة المناخ، والبحث بين آلاف الاحتمالات لتحضير تجارب جديدة.',
    note: 'العلماء يصمّمون التجارب ويتحققون من النتائج.' },
  { icon: 'palette', title: 'الفن والإبداع', c1: '#C2410C', c2: '#FBBF24', image: '',
    short: 'يمنحنا أفكارًا وأدوات جديدة للرسم والموسيقى والكتابة.',
    more: 'يمكنك أن تطلب منه اقتراحات لقصة أو ألوان لتصميم، ثم تختار منها وتضيف بصمتك الخاصة.',
    note: 'الإبداع الحقيقي يبدأ من خيالك أنت.' }
];

// Ethics scenario ("ماذا ستفعل؟")
const SCENARIO = {
  question: 'طلب منك أحد تطبيقات الذكاء الاصطناعي إدخال كلمة المرور الخاصة بك. ما التصرف الصحيح؟',
  options: [
    { text: 'أكتب كلمة المرور لأن التطبيق ذكي.', correct: false, feedback: 'ليس صحيحًا. كلمة المرور سرّ خاص بك، ولا تُعطى لأي تطبيق دون سبب موثوق.' },
    { text: 'لا أدخلها، وأسأل والديّ أو معلمي أولًا.', correct: true, feedback: 'أحسنت! حماية بياناتنا الشخصية تأتي أولًا، والاستشارة قبل المشاركة تصرف ذكي.' },
    { text: 'أشاركها مع صديقي ليجرب التطبيق.', correct: false, feedback: 'ليس صحيحًا. مشاركة كلمة المرور مع أي شخص تعرّض حسابك للخطر.' }
  ]
};

// One video under each section. Paste a verified YouTube video ID (the part after v= in the link)
// into `id`. While `id` is empty, a clearly labelled placeholder is shown. Nothing autoplays.
const VIDEOS = {
  'goal': { id: '', title: 'ما هو الذكاء الاصطناعي؟', text: 'مقدمة مبسطة تشرح فكرة الذكاء الاصطناعي وهدفه.' },
  'role': { id: '', title: 'الذكاء الاصطناعي في حياتنا', text: 'أمثلة على استخدامه في التعليم والطب والزراعة وغيرها.' },
  'ethics': { id: '', title: 'الاستخدام الآمن والمسؤول', text: 'نصائح للحفاظ على بياناتنا والتحقق من المعلومات.' },
  'pros-cons': { id: '', title: 'فوائد الذكاء الاصطناعي ومخاطره', text: 'نظرة متوازنة على مميزاته وسلبياته.' }
};

// Quiz (correct = index of correct option)
const QUIZ = [
  { q: 'ما الهدف الأساسي من الذكاء الاصطناعي؟', o: ['بناء أنظمة تساعد في أداء مهام تحتاج إلى ذكاء', 'استبدال كل البشر', 'تسلية الناس فقط', 'تخزين الملفات'], c: 0, f: 'الذكاء الاصطناعي يهدف إلى مساعدة الناس في مهام مثل تحليل المعلومات وحل المشكلات.' },
  { q: 'أيٌّ مما يلي مثال على استخدام الذكاء الاصطناعي في الحياة اليومية؟', o: ['مصباح عادي', 'تطبيق خرائط يقترح أسرع طريق', 'كتاب ورقي', 'مسطرة'], c: 1, f: 'تحلل تطبيقات الخرائط بيانات الطرق لتقترح مسارًا أفضل.' },
  { q: 'كيف يساعد الذكاء الاصطناعي في الطب؟', o: ['يحل محل الطبيب تمامًا', 'يساعد الطبيب على ملاحظة أمور في الصور الطبية', 'يمنع المرض', 'يصنع الدواء وحده دون مراجعة'], c: 1, f: 'يعمل كمساعد للطبيب، أما القرار فيبقى للطبيب.' },
  { q: 'ظهرت لك معلومة من أداة ذكاء اصطناعي ولست متأكدًا منها. ماذا تفعل؟', o: ['أصدّقها فورًا', 'أتحقق منها من مصدر موثوق', 'أنشرها بين أصدقائي', 'أتجاهل الأمر دائمًا'], c: 1, f: 'قد تخطئ هذه الأدوات، لذلك نتحقق دائمًا قبل أن نعتمد على المعلومة.' },
  { q: 'أي تصرف يُعدّ استخدامًا مسؤولًا للذكاء الاصطناعي؟', o: ['نسخ الواجب كما هو', 'مشاركة كلمة المرور', 'الاستعانة به لفهم درس ثم كتابة الإجابة بأسلوبي', 'استخدامه للسخرية من زميل'], c: 2, f: 'نستخدمه للتعلم والإبداع لا للغش أو الإيذاء.' },
  { q: 'أي مما يلي من سلبيات الذكاء الاصطناعي؟', o: ['الإسراع في إنجاز المهام', 'احتمال تقديم معلومات غير صحيحة', 'المساعدة في التعلم', 'تحليل بيانات كثيرة'], c: 1, f: 'قد يخطئ أو يكون متحيزًا، لذلك نراجع نتائجه.' },
  { q: 'ما معنى أن الذكاء الاصطناعي "أداة"؟', o: ['أنه يقرر كل شيء بدلًا منا', 'أن نتائجه تعتمد على طريقة استخدامنا له', 'أنه لا يفيد', 'أنه يشعر مثل الإنسان'], c: 1, f: 'الأداة القوية تفيد أو تضر بحسب طريقة استخدامها.' }
];

/* ---------- HELPERS ---------- */
const $ = (sel, root = document) => root.querySelector(sel);
const refreshIcons = () => { if (window.lucide) window.lucide.createIcons(); };

/** Creates an element with optional class and text. */
function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text) node.textContent = text;
  return node;
}

/** Adds an <img> over a gradient media box; removes it if loading fails. */
function addImage(box, src, alt) {
  if (!src) return;
  const img = el('img');
  img.src = src; img.alt = alt; img.loading = 'lazy';
  img.addEventListener('error', () => img.remove());
  box.appendChild(img);
}

/* ---------- NAVIGATION ---------- */
const navToggle = $('#navToggle');
const navLinks = $('#navLinks');

/** Opens/closes the mobile menu and keeps aria-expanded in sync. */
function setMenu(open) {
  navLinks.classList.toggle('open', open);
  navToggle.setAttribute('aria-expanded', String(open));
  navToggle.setAttribute('aria-label', open ? 'إغلاق القائمة' : 'فتح القائمة');
}
navToggle.addEventListener('click', () => setMenu(!navLinks.classList.contains('open')));
navLinks.addEventListener('click', e => { if (e.target.closest('a')) setMenu(false); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') setMenu(false); });

/** Highlights the nav link of the section currently in view. */
const spySections = [...document.querySelectorAll('#navLinks a')]
  .map(a => ({ link: a, section: $(a.getAttribute('href')) })).filter(x => x.section);
function updateActiveLink() {
  const y = window.scrollY + 120;
  let current = spySections[0];
  spySections.forEach(item => { if (item.section.offsetTop <= y) current = item; });
  spySections.forEach(item => {
    const active = item === current;
    item.link.classList.toggle('active', active);
    active ? item.link.setAttribute('aria-current', 'true') : item.link.removeAttribute('aria-current');
  });
}

/* ---------- OVERVIEW CARDS ---------- */
(function buildTopics() {
  const grid = $('#overviewGrid');
  TOPICS.forEach(t => {
    const card = el('article', 'card topic reveal');
    card.style.setProperty('--accent', t.accent);
    card.style.setProperty('--accent-bg', t.bg);
    const icon = el('div', 'icon-wrap');
    icon.innerHTML = `<i data-lucide="${t.icon}"></i>`;
    const link = el('a', 'btn', 'انتقل إلى القسم');
    link.href = '#' + t.id;
    card.append(icon, el('h3', '', t.title), link);
    grid.appendChild(card);
  });
})();

/* ---------- ROLE CARDS + MODAL ---------- */
const modal = $('#modal');
let lastTrigger = null;

/** Opens the details modal for an application and moves focus into it. */
function openModal(app, trigger) {
  lastTrigger = trigger;
  $('#modalTitle').textContent = app.title;
  $('#modalText').textContent = app.more;
  $('#modalNote').textContent = app.note;
  const media = $('#modalMedia');
  media.innerHTML = `<i data-lucide="${app.icon}"></i>`;
  media.style.setProperty('--c1', app.c1); media.style.setProperty('--c2', app.c2);
  addImage(media, app.image, app.title);
  refreshIcons();
  modal.hidden = false;
  $('#modalClose').focus();
}
function closeModal() {
  modal.hidden = true;
  if (lastTrigger) lastTrigger.focus();
}
$('#modalClose').addEventListener('click', closeModal);
modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !modal.hidden) closeModal(); });

(function buildApplications() {
  const grid = $('#roleGrid');
  APPLICATIONS.forEach(app => {
    const card = el('button', 'card app-card reveal');
    card.type = 'button';
    card.setAttribute('aria-haspopup', 'dialog');
    const media = el('div', 'app-media');
    media.style.setProperty('--c1', app.c1); media.style.setProperty('--c2', app.c2);
    media.innerHTML = `<i data-lucide="${app.icon}"></i>`;
    addImage(media, app.image, app.title);
    const body = el('div', 'app-body');
    body.append(el('h3', '', app.title), el('p', '', app.short));
    const more = el('span', 'more', 'اعرف المزيد');
    body.appendChild(more);
    card.append(media, body);
    card.addEventListener('click', () => openModal(app, card));
    grid.appendChild(card);
  });
})();

/* ---------- ETHICS SCENARIO ---------- */
(function buildScenario() {
  $('#scenarioQ').textContent = SCENARIO.question;
  const box = $('#scenarioOptions');
  const fb = $('#scenarioFeedback');
  SCENARIO.options.forEach(opt => {
    const b = el('button', 'option');
    b.type = 'button';
    b.append(el('span', 'text', opt.text));
    b.addEventListener('click', () => {
      // Lock all answers, mark right/wrong with an icon AND color, then explain.
      [...box.children].forEach((btn, i) => {
        btn.disabled = true;
        const ok = SCENARIO.options[i].correct;
        if (btn === b || ok) {
          btn.classList.add(ok ? 'correct' : 'wrong');
          btn.prepend(Object.assign(el('span', 'mark', ok ? '✓' : '✕'), { ariaHidden: 'true' }));
        }
      });
      fb.textContent = opt.feedback;
      fb.className = 'feedback ' + (opt.correct ? 'good' : 'bad');
      if (!opt.correct) addRetry(box, fb);
    });
    box.appendChild(b);
  });

  /** Lets the student try the scenario again after a wrong answer. */
  function addRetry(container, feedbackEl) {
    const retry = el('button', 'btn btn-outline', 'جرّب مرة أخرى');
    retry.type = 'button';
    retry.addEventListener('click', () => {
      container.innerHTML = ''; feedbackEl.textContent = ''; feedbackEl.className = 'feedback';
      buildScenario();
    });
    feedbackEl.after(retry);
    retry.addEventListener('click', () => retry.remove());
  }
})();

/* ---------- VIDEOS ---------- */
/** Fills every [data-video] slot in the page with that section's video (or a placeholder). */
(function buildVideos() {
  document.querySelectorAll('[data-video]').forEach(slot => {
    const v = VIDEOS[slot.dataset.video];
    if (!v) return;
    const card = el('article', 'video-card reveal');
    const head = el('div', 'video-head');
    head.innerHTML = '<i data-lucide="circle-play"></i>';
    head.append(el('span', '', 'شاهد وتعلّم: ' + v.title));
    const frame = el('div', 'video-frame');
    if (v.id) {
      const iframe = el('iframe');
      iframe.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(v.id); // no autoplay
      iframe.title = v.title; iframe.loading = 'lazy'; iframe.allowFullscreen = true;
      iframe.allow = 'accelerometer; encrypted-media; gyroscope; picture-in-picture';
      frame.appendChild(iframe);
    } else {
      const ph = el('div', 'video-placeholder');
      ph.innerHTML = 'مكان مخصص للفيديو (لم يُضف رابط بعد).<br>ضع معرّف فيديو يوتيوب في <code>VIDEOS[\'' + slot.dataset.video + '\'].id</code> داخل script.js';
      frame.appendChild(ph);
    }
    card.append(head, frame, el('p', 'video-text', v.text));
    slot.appendChild(card);
  });
})();

/* ---------- QUIZ ---------- */
const quizState = { index: 0, answers: new Array(QUIZ.length).fill(null) };
const qBody = $('#quizBody'), qFb = $('#quizFeedback');
const prevBtn = $('#prevBtn'), nextBtn = $('#nextBtn');

/** Draws the current question and restores any answer already given. */
function renderQuestion() {
  const { index, answers } = quizState;
  const item = QUIZ[index];
  const picked = answers[index];
  $('#quizCount').textContent = `السؤال ${index + 1} من ${QUIZ.length}`;
  const pct = Math.round((index / QUIZ.length) * 100);
  $('#quizBar').style.width = pct + '%';
  $('#quizProgress').setAttribute('aria-valuenow', pct);
  $('#quizProgress').setAttribute('aria-label', `تقدمك في الاختبار ${pct}%`);

  qBody.innerHTML = '';
  qBody.appendChild(el('p', 'q-text', item.q));
  const list = el('div', 'options');
  list.setAttribute('role', 'group');
  item.o.forEach((text, i) => {
    const b = el('button', 'option');
    b.type = 'button';
    b.append(el('span', 'text', text));
    b.addEventListener('click', () => selectAnswer(i));
    list.appendChild(b);
  });
  qBody.appendChild(list);

  if (picked !== null) showFeedback(picked); else { qFb.textContent = ''; qFb.className = 'feedback'; }
  prevBtn.disabled = index === 0;
  nextBtn.disabled = picked === null;
  nextBtn.textContent = index === QUIZ.length - 1 ? 'عرض النتيجة' : 'التالي';
}

/** Records the answer (once per question) and shows feedback. */
function selectAnswer(i) {
  if (quizState.answers[quizState.index] !== null) return;
  quizState.answers[quizState.index] = i;
  showFeedback(i);
  nextBtn.disabled = false;
}

/** Marks options correct/wrong (icon + color) and writes the explanation. */
function showFeedback(i) {
  const item = QUIZ[quizState.index];
  const ok = i === item.c;
  [...qBody.querySelectorAll('.option')].forEach((btn, n) => {
    btn.disabled = true;
    if (n === item.c || n === i) {
      btn.classList.add(n === item.c ? 'correct' : 'wrong');
      btn.prepend(el('span', 'mark', n === item.c ? '✓' : '✕'));
    }
  });
  qFb.textContent = (ok ? 'إجابة صحيحة! ' : 'ليست الإجابة الصحيحة. ') + item.f;
  qFb.className = 'feedback ' + (ok ? 'good' : 'bad');
}

prevBtn.addEventListener('click', () => { if (quizState.index > 0) { quizState.index--; renderQuestion(); } });
nextBtn.addEventListener('click', () => {
  if (quizState.index < QUIZ.length - 1) { quizState.index++; renderQuestion(); }
  else showResult();
});

/** Calculates the score and shows a message that fits it. */
function showResult() {
  const score = quizState.answers.filter((a, i) => a === QUIZ[i].c).length;
  const ratio = score / QUIZ.length;
  let title, text;
  if (ratio >= 0.85) { title = 'مستكشف ذكي!'; text = 'ممتاز! فهمت الذكاء الاصطناعي واستخدامه المسؤول جيدًا.'; }
  else if (ratio >= 0.6) { title = 'أحسنت!'; text = 'نتيجة جيدة. راجع الأقسام التي أخطأت فيها لتصبح أقوى.'; }
  else { title = 'بداية جيدة'; text = 'لا بأس، المعرفة تُبنى بالمحاولة. اقرأ الأقسام مرة أخرى وأعد الاختبار.'; }
  $('#resultTitle').textContent = `${title} — نتيجتك ${score} من ${QUIZ.length}`;
  $('#resultText').textContent = text;
  $('#quizBox').hidden = true;
  $('#quizResult').hidden = false;
  $('#quizResult').scrollIntoView({ block: 'center' });
}

$('#restartBtn').addEventListener('click', () => {
  quizState.index = 0; quizState.answers.fill(null);
  $('#quizResult').hidden = true; $('#quizBox').hidden = false;
  renderQuestion();
  $('#quizBox').scrollIntoView({ block: 'center' });
});

/* ---------- SCROLL REVEAL ---------- */
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const revealObserver = 'IntersectionObserver' in window && !reducedMotion
  ? new IntersectionObserver(entries => entries.forEach(en => {
      if (en.isIntersecting) { en.target.classList.add('visible'); revealObserver.unobserve(en.target); }
    }), { threshold: 0.12 })
  : null;
document.querySelectorAll('.reveal').forEach(node => revealObserver ? revealObserver.observe(node) : node.classList.add('visible'));

/* ---------- BACK TO TOP ---------- */
const floatTop = $('#floatTop');
const goTop = () => window.scrollTo({ top: 0, behavior: reducedMotion ? 'auto' : 'smooth' });
floatTop.addEventListener('click', goTop);
$('#toTopBtn').addEventListener('click', goTop);
window.addEventListener('scroll', () => {
  floatTop.classList.toggle('show', window.scrollY > 700);
  updateActiveLink();
}, { passive: true });

/* ---------- INIT ---------- */
addImage($('#goalImage'), GOAL_IMAGE, 'صورة تعبّر عن هدف الذكاء الاصطناعي');
renderQuestion();
updateActiveLink();
refreshIcons();
